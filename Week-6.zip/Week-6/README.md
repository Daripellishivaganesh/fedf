Simple Weather App (RapidAPI)

What this is
- A minimal single-file HTML page `index.html` that lets you enter a city and a RapidAPI key and fetches current weather using the RapidAPI community OpenWeatherMap endpoint.

How to get a RapidAPI key
1. Create an account at https://rapidapi.com
2. Search for "OpenWeatherMap" or "community-open-weather-map" and subscribe to the (free) endpoint.
3. Copy your RapidAPI Key from the RapidAPI dashboard.

How to use
- Open `index.html` in your browser (double-click the file). No server required.
- Paste your RapidAPI key into the "RapidAPI Key" field.
- Type a city name and click "Get Weather". Results show temperature, humidity, description, wind and a toggle to view raw JSON.

Notes & troubleshooting
- CORS: RapidAPI endpoints normally allow browser requests. If you get a CORS error the endpoint may be configured to block direct browser requests for your key; in that case run a tiny local server (see below) or use a backend proxy.

Start a local static server (optional)
- If you prefer to run a local server, from the folder containing `index.html` run one of these commands in PowerShell:

# using Python 3.11+ if available
python -m http.server 8000

# or using Node.js (if you have http-server installed)
npx http-server -p 8000

Open http://localhost:8000 in your browser.

Alternative: WeatherAPI on RapidAPI
- If you'd rather use the "WeatherAPI" provider on RapidAPI (different host and params), you can adapt the fetch headers in `index.html` to use the host value shown on RapidAPI and adjust the path/parameters per their docs.

Security
- Keep your RapidAPI key secret. Do not commit it to public repositories.

Credits
- Uses RapidAPI community OpenWeatherMap (https://rapidapi.com/community)